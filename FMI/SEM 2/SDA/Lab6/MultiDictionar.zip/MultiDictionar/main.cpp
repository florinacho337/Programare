#include <iostream>
#include "TestExtins.h"
#include "TestScurt.h"

using namespace std;

int main() {

	testAll();
	testAllExtins();

	cout<<"End";

}
