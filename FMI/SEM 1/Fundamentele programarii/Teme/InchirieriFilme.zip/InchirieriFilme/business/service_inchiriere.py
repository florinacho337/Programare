class ServiceInchiriere:

    def __init__(self, validator_inchiriere, repo_inchirieri):
        self.__validator_inchiriere = validator_inchiriere
        self.__repo_inchirieri = repo_inchirieri
