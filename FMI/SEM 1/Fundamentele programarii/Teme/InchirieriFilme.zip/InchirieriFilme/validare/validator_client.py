class ValidareClient:

    def __int__(self):
        pass

    def valideaza(self, client):
        pass