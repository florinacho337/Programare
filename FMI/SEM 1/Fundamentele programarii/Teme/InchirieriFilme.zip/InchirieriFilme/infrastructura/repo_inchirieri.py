class RepoInchirieri:

    def __int__(self):
        pass