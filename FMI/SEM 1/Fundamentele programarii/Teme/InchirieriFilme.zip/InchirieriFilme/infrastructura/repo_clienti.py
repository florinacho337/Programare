class RepoClienti:

    def __int__(self):
        pass