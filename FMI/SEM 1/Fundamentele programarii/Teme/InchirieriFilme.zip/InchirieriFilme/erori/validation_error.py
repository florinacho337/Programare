class ValidationError(Exception):
    pass