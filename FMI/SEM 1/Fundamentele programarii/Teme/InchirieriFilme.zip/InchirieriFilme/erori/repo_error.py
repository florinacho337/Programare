class RepoError(Exception):
    pass